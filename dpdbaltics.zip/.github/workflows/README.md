#Steps needed to trigger a module build:
* Navigate to repository
* Create new release
* Add needed tag
##Github documentation for releases:
https://docs.github.com/en/enterprise-server@3.1/repositories/releasing-projects-on-github/managing-releases-in-a-repository

