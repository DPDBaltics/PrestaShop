CREATE TABLE IF NOT EXISTS `PREFIX_dpd_cod_payment_modules` (
  `id_dpd_cod_payment_modules` INT(11) UNSIGNED AUTO_INCREMENT,
  `id_payment_module` INT(11) NOT NULL,
  PRIMARY KEY (`id_dpd_cod_payment_modules`)
) ENGINE=ENGINE_TYPE DEFAULT CHARSET=utf8;