DROP TABLE IF EXISTS `PREFIX_dpd_receiver_address`;
